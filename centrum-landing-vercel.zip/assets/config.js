// ============================================================
//  CENTRUM CHIRCHIQ — LANDING SOZLAMALARI
//  Shu faylni o'zgartirsangiz, barcha 4 ta sahifa yangilanadi.
//  Bo'sh qoldirilgan qiymat o'rniga "Narxini menejerdan bilib oling" yoziladi.
// ============================================================
window.CC_CONFIG = {
  // 1 m² narxi (kartochkada: "Kvadrat metr narxi ... boshlanadi")
  priceM2: "7 mln so‘mdan",

  // 2-sahifadagi (10 mln bosh to'lov) oylik to'lov, masalan: "4 500 000 so'm"
  monthlyV2: "",

  // Telefon va Telegram
  phone: "+998776032222",
  phoneText: "77 603 2222",
  telegram: "https://t.me/centrumchirchiq",

  // Meta (Facebook) Pixel ID — bo'lsa yozing, masalan "1234567890123456"
  pixelId: "",

  // Taklif taymeri (daqiqa). 0 bo'lsa taymer ko'rinmaydi
  timerMinutes: 2
};
