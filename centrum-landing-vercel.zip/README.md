# Centrum Chirchiq — landing sahifalar (Vercel)

Sahifalar:
- `/1/` — Chirchiq markazidan 40 mln bosh to‘lov bilan xonadon
- `/2/` — Chirchiqdan 10 mln bosh to‘lov bilan xonadon
- `/3/` — Chirchiqdan oyiga 6 mln so‘m to‘lov bilan xonadon
- `/4/` — Chirchiqdan xonadon 311 mln so‘mga, 40 oyga bo‘lib to‘lash

## Narx va sozlamalar
`assets/config.js` faylida: 1 m² narxi, 2-sahifadagi oylik to‘lov, telefon, Telegram, Meta Pixel ID, taymer.

## Vercel'ga joylash
1. GitHub'da yangi repozitoriy oching va shu papkadagi barcha fayllarni yuklang.
2. vercel.com → Add New → Project → shu repozitoriyni tanlang → Deploy (sozlamalarni o‘zgartirish shart emas).
3. Settings → Environment Variables: `TELEGRAM_BOT_TOKEN` va `TELEGRAM_CHAT_ID` qo‘shing, keyin Redeploy.
4. Arizalar Telegram guruhingizga landing raqami va UTM belgilar bilan tushadi.
