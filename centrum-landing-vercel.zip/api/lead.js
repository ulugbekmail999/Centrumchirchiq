// Vercel serverless function: sends a landing-page lead to Telegram.
// Vercel > Project > Settings > Environment Variables:
//   TELEGRAM_BOT_TOKEN  — token from @BotFather
//   TELEGRAM_CHAT_ID    — group/chat id where leads should arrive (e.g. -1001234567890)
module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ ok: false });
  const token = process.env.TELEGRAM_BOT_TOKEN, chat = process.env.TELEGRAM_CHAT_ID;
  if (!token || !chat) return res.status(503).json({ ok: false, error: 'not configured' });
  let b = req.body || {};
  if (typeof b === 'string') { try { b = JSON.parse(b); } catch (e) { b = {}; } }
  const clean = (v, n) => String(v || '').slice(0, n).replace(/[<>]/g, '');
  const phone = clean(b.phone, 20), name = clean(b.name, 80), variant = clean(b.variant, 4), page = clean(b.page, 60);
  if (!/^\+998\d{9}$/.test(phone)) return res.status(400).json({ ok: false });
  const utm = b.utm && typeof b.utm === 'object' ? Object.entries(b.utm).slice(0, 6).map(([k, v]) => `${clean(k, 20)}: ${clean(v, 80)}`).join('\n') : '';
  const titles = { '1': '40 mln bosh to‘lov', '2': '10 mln bosh to‘lov', '3': 'oyiga 6 mln', '4': '311 mln, 40 oy' };
  const text = `🏢 Centrum Chirchiq — yangi lid\n📄 Landing ${variant}: ${titles[variant] || page}\n👤 ${name || '—'}\n📞 ${phone}${utm ? '\n\n' + utm : ''}`;
  try {
    const r = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ chat_id: chat, text }) });
    return res.status(r.ok ? 200 : 502).json({ ok: r.ok });
  } catch (e) { return res.status(502).json({ ok: false }); }
};
